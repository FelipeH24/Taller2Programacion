package co.edu.unbosque.configuration;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import co.edu.unbosque.model.Student;
import co.edu.unbosque.repository.StudentRepository;
import co.edu.unbosque.util.AESUtil;

@Configuration
public class LoadDataBase {

	private static final Logger LOG = LoggerFactory.getLogger(LoadDataBase.class);

	@Bean
	CommandLineRunner initDataBase(StudentRepository stuRep) {
		return args -> {
			Optional<Student> foud = stuRep.findByStudentName(AESUtil.encrypt("admin"));
			if (foud.isPresent()) {
				LOG.info("Admin already exist, skipping admin creation");
			} else {
				stuRep.save(new Student(AESUtil.encrypt("admin"), AESUtil.encrypt("5"), AESUtil.encrypt("5"),
						AESUtil.encrypt("5"), AESUtil.encrypt("5")));
				LOG.info("pre-loading admin-user");
			}
		};
	}
}
