package co.edu.unbosque.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.edu.unbosque.model.Student;
import co.edu.unbosque.repository.StudentRepository;
import co.edu.unbosque.util.AESUtil;

@Service
public class StudentService implements CRUDOperations<Student> {
	@Autowired
	private StudentRepository studentRep;

	public StudentService() {

	}

	@Override
	public int create(Student data) {

		if (findStudentnameAlreadyTaken(data)) {
			return 1;
		} else {
			String n = String.valueOf(calculateAverage(data));
			Student temp = new Student(AESUtil.encrypt(data.getStudentName()), AESUtil.encrypt(data.getNota1()),
					AESUtil.encrypt(data.getNota2()), AESUtil.encrypt(data.getNota3()),
					AESUtil.encrypt(n));
			studentRep.save(temp);
		}

		return 0;
	}

	@Override
	public List<Student> getAll() {
		List<Student> database = studentRep.findAll();
		List<Student> decrypted = new ArrayList<>();

		for (Student data : database) {
			Student newS = new Student();
			newS.setId(data.getId());
			newS.setStudentName(AESUtil.decrypt(data.getStudentName()));
			newS.setNota1(AESUtil.decrypt(data.getNota1()));
			newS.setNota2(AESUtil.decrypt(data.getNota2()));
			newS.setNota3(AESUtil.decrypt(data.getNota3()));
			newS.setPromedio(AESUtil.decrypt(data.getPromedio()));
			decrypted.add(newS);
		}

		return decrypted;
	}

	@Override
	public int deleteById(Long id) {
		Optional<Student> found = studentRep.findById(id);
		if (found.isPresent()) {
			studentRep.delete(found.get());
			return 0;
		} else {
			return 1;
		}
	}

	@Override
	public int update(Long id, Student newData) {
		Optional<Student> found = studentRep.findById(id);
		Optional<Student> newFound = studentRep.findByStudentName(newData.getStudentName());
		if (found.isPresent() && !newFound.isPresent()) {
			Student temp = found.get();
			temp.setStudentName(AESUtil.encrypt(newData.getStudentName()));
			temp.setNota1(AESUtil.encrypt(newData.getNota1()));
			temp.setNota2(AESUtil.encrypt(newData.getNota2()));
			temp.setNota3(AESUtil.encrypt(newData.getNota3()));
			temp.setPromedio(AESUtil.encrypt(newData.getPromedio()));
			studentRep.save(temp);
			return 0;
		} else if (found.isPresent() && newFound.isPresent()) {
			return 1;
		} else if (!found.isEmpty()) {
			return 2;
		} else {
			return 3;
		}

	}

	@Override
	public long count() {
		return studentRep.count();
	}

	@Override
	public boolean exists(Long id) {

		return studentRep.existsById(id) ? true : false;
	}

	public boolean findStudentnameAlreadyTaken(Student newStudent) {
		Optional<Student> found = studentRep.findByStudentName(AESUtil.encrypt(newStudent.getStudentName()));
		if (found.isPresent()) {
			return true;
		} else {
			return false;
		}

	}

	public double calculateAverage(Student student) {
		try {
			String firstNote = student.getNota1();
            String secondNote = student.getNota2();
            String thirdNote = student.getNota3();
            double note1 = Double.parseDouble(firstNote) * 0.30;
            double note2 = Double.parseDouble(secondNote) * 0.30;
            double note3 = Double.parseDouble(thirdNote) * 0.40;
            double finalNote = note1 + note2 + note3;
            return finalNote;
		} catch (NumberFormatException | NullPointerException e) {
			e.printStackTrace();
			return 0.0;
		}
	}

}