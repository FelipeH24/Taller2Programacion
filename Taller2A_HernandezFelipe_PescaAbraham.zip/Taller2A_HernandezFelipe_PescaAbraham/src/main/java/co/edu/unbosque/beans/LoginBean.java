package co.edu.unbosque.beans;

import co.edu.unbosque.controller.HttpClientSynchronous;
import co.edu.unbosque.util.AESUtil;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.annotation.ManagedBean;
import jakarta.enterprise.context.RequestScoped;

@ManagedBean
@RequestScoped
public class LoginBean {

    private String studentName;
    private String nota1;
    private String nota2;
    private String nota3;
    private String promedio;

    public LoginBean() {
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getNota1() {
        return nota1;
    }

    public void setNota1(String nota1) {
        this.nota1 = nota1;
    }

    public String getNota2() {
        return nota2;
    }

    public void setNota2(String nota2) {
        this.nota2 = nota2;
    }

    public String getNota3() {
        return nota3;
    }

    public void setNota3(String nota3) {
        this.nota3 = nota3;
    }

    public String getPromedio() {
        return promedio;
    }

    public void setPromedio(String promedio) {
        this.promedio = promedio;
    }

//    public void addMessage(FacesMessage.Severity severity, String summary, String detail) {
//        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, summary, detail));
//    }

    public void showSticky(String messages, FacesMessage.Severity severity) {
        FacesContext.getCurrentInstance().addMessage("Cundi",
                new FacesMessage(severity, "Nota calculada: ", messages));
    }

    public String create() {
        try {
            String url = "http://localhost:8081/Student/createStudentjson";
            String requestBody = "{\"studentName\":\"" + AESUtil.encrypt(studentName) + "\",\"nota1\":\"" + AESUtil.encrypt(nota1)
                    + "\",\"nota2\":\"" + AESUtil.encrypt(nota2) + "\",\"nota3\":\"" + AESUtil.encrypt(nota3) + "\"}";
            String m = HttpClientSynchronous.doPost(url, requestBody);

            if (m.startsWith("Que")) {
                showSticky(m, FacesMessage.SEVERITY_WARN);
            } else if (m.startsWith("Pasaste")) {
                showSticky(m, FacesMessage.SEVERITY_INFO);
            } else if (m.startsWith("Dediquese")) {
                showSticky(m, FacesMessage.SEVERITY_ERROR);
            }
        } catch (Exception e) {
            e.printStackTrace();
            showSticky("Se bugeó", FacesMessage.SEVERITY_FATAL);
        }

        return null;
    }

    public void matchPasswords() {
        // Implementation for matching passwords
    }
}
